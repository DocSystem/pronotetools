var s = document.createElement("script");
s.src = "https://docsystem.xyz/pronotetools/tools.js";
document.querySelector("head").appendChild(s);
